
#include <stdio.h>

int main() {
    int correctPIN = 4821;
    int enteredPIN;
    int attempts = 3;
    int choice;
    int transactionCount = 0;
    float balance = 12500.00;
    float amount;

    // TASK 1: PIN Verification
    printf("===== ATM MACHINE =====\n");

    while (attempts > 0) {
        printf("\nEnter PIN: ");
        scanf("%d", &enteredPIN);

        if (enteredPIN == correctPIN) {
            printf("\nLogin Successful!\n");
            break;
        } else {
            attempts--;

            if (attempts > 0) {
                printf("Incorrect PIN. %d attempts remaining.\n",
                       attempts);
            } else {
                printf("Incorrect PIN. Your card has been blocked.\n");
                printf("Please visit your nearest branch.\n");
                return 0;
            }
        }
    }

    // TASK 2 & 3: Transaction Menu
    while (transactionCount < 5) {

        printf("\n===== Welcome =====\n");
        printf("Balance: Rs. %.2f\n", balance);
        printf("-------------------\n");
        printf("1. Check Balance\n");
        printf("2. Withdraw\n");
        printf("3. Deposit\n");
        printf("4. Exit\n");
        printf("===================\n");

        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {

            case 1:
                printf("\nCurrent Balance: Rs. %.2f\n", balance);
                break;

            case 2:
                printf("Enter withdrawal amount: Rs. ");
                scanf("%f", &amount);

                if (amount > balance) {
                    printf("Insufficient balance!\n");
                }
                else if (amount <= 0) {
                    printf("Invalid amount!\n");
                }
                else if ((int)amount % 100 != 0 || amount != (int)amount) {
                    printf("Amount must be a multiple of 100!\n");
                }
                else {
                    balance -= amount;
                    transactionCount++;

                    printf("\n----- Mini Receipt -----\n");
                    printf("Transaction : Withdrawal\n");
                    printf("Amount      : Rs. %.2f\n", amount);
                    printf("Balance     : Rs. %.2f\n", balance);
                    printf("Txn No.     : %d\n", transactionCount);
                }
                break;

            case 3:
                printf("Enter deposit amount: Rs. ");
                scanf("%f", &amount);

                if (amount <= 0) {
                    printf("Invalid deposit amount!\n");
                }
                else {
                    balance += amount;
                    transactionCount++;

                    printf("\n----- Mini Receipt -----\n");
                    printf("Transaction : Deposit\n");
                    printf("Amount      : Rs. %.2f\n", amount);
                    printf("Balance     : Rs. %.2f\n", balance);
                    printf("Txn No.     : %d\n", transactionCount);
                }
                break;

            case 4:
                printf("\nFinal Balance: Rs. %.2f\n", balance);
                printf("Thank you for using our ATM!\n");
                return 0;

            default:
                printf("Invalid choice! Try again.\n");
        }

        if (transactionCount == 5) {
            printf("\nTransaction limit reached. Please re-login.\n");
            printf("Final Balance: Rs. %.2f\n", balance);
            break;
        }
    }

    return 0;
}
