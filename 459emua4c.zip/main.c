
#include <stdio.h>
#include <math.h>

// Function declarations
float compute_tip(float bill, float tip_pct);
float compute_total(float bill, float tip);
float per_person_share(float total, int people);

void display_summary(float bill, float tip, float total,
                     int people, float share);

float collect_items(int person_num);
void round_up(float *amount);

int main() {
    int choice, people;
    float bill, tip_pct, tip, total, share;
    float subtotal[100], grand_total;
    float tip_share, final_amount, rounded_amount;

    do {
        printf("\n===== Bill Splitter =====\n");
        printf("1. Split Equally\n");
        printf("2. Split by Items\n");
        printf("3. Exit\n");
        printf("=========================\n");

        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {

            // TASK 1: Equal Split
            case 1:

                printf("\nEnter bill amount: Rs. ");
                scanf("%f", &bill);

                if (bill <= 0) {
                    printf("Invalid bill amount!\n");
                    break;
                }

                printf("Enter tip percentage (0-50): ");
                scanf("%f", &tip_pct);

                if (tip_pct < 0 || tip_pct > 50) {
                    printf("Invalid tip percentage!\n");
                    break;
                }

                printf("Enter number of people: ");
                scanf("%d", &people);

                if (people < 1) {
                    printf("Invalid number of people!\n");
                    break;
                }

                tip = compute_tip(bill, tip_pct);
                total = compute_total(bill, tip);
                share = per_person_share(total, people);

                display_summary(bill, tip, total,
                                people, share);

                rounded_amount = share;
                round_up(&rounded_amount);

                printf("Rounded Share : Rs. %.2f\n",
                       rounded_amount);

                break;

            // TASK 2: Individual Item Split
            case 2:

                printf("\nEnter number of people: ");
                scanf("%d", &people);

                if (people < 1 || people > 100) {
                    printf("Invalid number of people!\n");
                    break;
                }

                printf("Enter tip percentage (0-50): ");
                scanf("%f", &tip_pct);

                if (tip_pct < 0 || tip_pct > 50) {
                    printf("Invalid tip percentage!\n");
                    break;
                }

                grand_total = 0;

                for (int i = 0; i < people; i++) {
                    subtotal[i] = collect_items(i + 1);
                    grand_total += subtotal[i];
                }

                tip = compute_tip(grand_total, tip_pct);
                total = compute_total(grand_total, tip);

                printf("\n===== Individual Bill Summary =====\n");
                printf("Grand Total : Rs. %.2f\n", grand_total);
                printf("Total Tip   : Rs. %.2f\n", tip);
                printf("Final Total : Rs. %.2f\n", total);

                for (int i = 0; i < people; i++) {

                    if (grand_total > 0) {
                        tip_share = (subtotal[i] / grand_total) * tip;
                    } else {
                        tip_share = 0;
                    }

                    final_amount = subtotal[i] + tip_share;

                    printf("\nPerson %d\n", i + 1);
                    printf("Items       : Rs. %.2f\n", subtotal[i]);
                    printf("Tip Share   : Rs. %.2f\n", tip_share);
                    printf("Final Amount: Rs. %.2f\n", final_amount);
                }

                break;

            // TASK 3: Exit
            case 3:
                printf("\nThank you for using Bill Splitter!\n");
                break;

            default:
                printf("Invalid choice! Try again.\n");
        }

    } while (choice != 3);

    return 0;
}

// Calculate tip
float compute_tip(float bill, float tip_pct) {
    return bill * tip_pct / 100;
}

// Calculate total bill
float compute_total(float bill, float tip) {
    return bill + tip;
}

// Calculate per person share
float per_person_share(float total, int people) {
    return total / people;
}

// Display equal split summary
void display_summary(float bill, float tip, float total,
                     int people, float share) {

    printf("\n======= Bill Summary =======\n");
    printf("Bill Amount   : Rs. %.2f\n", bill);
    printf("Tip           : Rs. %.2f\n", tip);
    printf("Total         : Rs. %.2f\n", total);
    printf("People        : %d\n", people);
    printf("Per Person    : Rs. %.2f\n", share);
    printf("============================\n");
}

// Collect individual item costs
float collect_items(int person_num) {
    float item, subtotal = 0;

    printf("\nPerson %d - Enter item costs (0 to stop):\n",
           person_num);

    while (1) {
        printf("Enter item cost: Rs. ");
        scanf("%f", &item);

        if (item == 0) {
            break;
        }

        if (item < 0) {
            printf("Invalid item cost! Enter a positive amount.\n");
            continue;
        }

        subtotal += item;
    }

    return subtotal;
}

// Round amount up to nearest rupee
void round_up(float *amount) {
    *amount = ceil(*amount);
}
