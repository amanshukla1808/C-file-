
#include <stdio.h>

// Function declarations
int count_words(char str[]);
int count_vowels(char str[]);
int count_consonants(char str[]);
int count_digits(char str[]);
int count_sentences(char str[]);
int count_spaces(char str[]);
char most_frequent_char(char str[]);
void display_analysis(char str[]);

int main() {

    char text[500];
    char lines[10][500];
    int n, total_words = 0;
    int max_words = -1;
    int max_line = 0;

    // TASK 1 & 2: Single Line Analysis
    printf("===== TEXT ANALYSIS TOOL =====\n");

    printf("\nEnter a line of text:\n");
    fgets(text, sizeof(text), stdin);

    display_analysis(text);

    // TASK 3: Multi-Line Analysis
    printf("\n===== MULTI-LINE ANALYSIS =====\n");

    printf("Enter number of lines (1-10): ");
    scanf("%d", &n);

    if (n < 1 || n > 10) {
        printf("Invalid number of lines!\n");
        return 0;
    }

    // Clear remaining newline from input buffer
    getchar();

    // Input multiple lines
    for (int i = 0; i < n; i++) {
        printf("\nEnter line %d:\n", i + 1);
        fgets(lines[i], sizeof(lines[i]), stdin);
    }

    // Display word count for each line
    printf("\n===== LINE-WISE WORD COUNT =====\n");

    for (int i = 0; i < n; i++) {

        int words = count_words(lines[i]);

        printf("Line %d: %d words\n", i + 1, words);

        total_words += words;

        if (words > max_words) {
            max_words = words;
            max_line = i;
        }
    }

    // Combined result
    printf("\n===== FINAL SUMMARY =====\n");

    printf("Total Lines      : %d\n", n);
    printf("Total Words      : %d\n", total_words);

    printf("Line with most words: Line %d\n", max_line + 1);
    printf("Text: %s", lines[max_line]);

    printf("\n============================\n");

    return 0;
}

// Count words
int count_words(char str[]) {

    int count = 0;
    int in_word = 0;

    for (int i = 0; str[i] != '\0'; i++) {

        if (str[i] != ' ' && str[i] != '\n' &&
            str[i] != '\t') {

            if (in_word == 0) {
                count++;
                in_word = 1;
            }

        } else {
            in_word = 0;
        }
    }

    return count;
}

// Count vowels
int count_vowels(char str[]) {

    int count = 0;

    for (int i = 0; str[i] != '\0'; i++) {

        char ch = str[i];

        if (ch == 'a' || ch == 'e' || ch == 'i' ||
            ch == 'o' || ch == 'u' ||
            ch == 'A' || ch == 'E' || ch == 'I' ||
            ch == 'O' || ch == 'U') {

            count++;
        }
    }

    return count;
}

// Count consonants
int count_consonants(char str[]) {

    int count = 0;

    for (int i = 0; str[i] != '\0'; i++) {

        char ch = str[i];

        if ((ch >= 'a' && ch <= 'z') ||
            (ch >= 'A' && ch <= 'Z')) {

            if (!(ch == 'a' || ch == 'e' || ch == 'i' ||
                  ch == 'o' || ch == 'u' ||
                  ch == 'A' || ch == 'E' || ch == 'I' ||
                  ch == 'O' || ch == 'U')) {

                count++;
            }
        }
    }

    return count;
}

// Count digits
int count_digits(char str[]) {

    int count = 0;

    for (int i = 0; str[i] != '\0'; i++) {

        if (str[i] >= '0' && str[i] <= '9') {
            count++;
        }
    }

    return count;
}

// Count sentences
int count_sentences(char str[]) {

    int count = 0;

    for (int i = 0; str[i] != '\0'; i++) {

        if (str[i] == '.' || str[i] == '!' ||
            str[i] == '?') {

            count++;
        }
    }

    return count;
}

// Count spaces
int count_spaces(char str[]) {

    int count = 0;

    for (int i = 0; str[i] != '\0'; i++) {

        if (str[i] == ' ') {
            count++;
        }
    }

    return count;
}

// Find most frequent alphabetic character
char most_frequent_char(char str[]) {

    int frequency[26] = {0};
    int max = 0;
    char result = '\0';

    for (int i = 0; str[i] != '\0'; i++) {

        char ch = str[i];

        if (ch >= 'A' && ch <= 'Z') {
            ch = ch + 32;
        }

        if (ch >= 'a' && ch <= 'z') {

            int index = ch - 'a';

            frequency[index]++;

            if (frequency[index] > max) {
                max = frequency[index];
                result = ch;
            }
        }
    }

    return result;
}

// Display complete analysis
void display_analysis(char str[]) {

    char frequent = most_frequent_char(str);

    printf("\n===== TEXT ANALYSIS =====\n");

    printf("Input       : %s", str);
    printf("Words       : %d\n", count_words(str));
    printf("Vowels      : %d\n", count_vowels(str));
    printf("Consonants  : %d\n", count_consonants(str));
    printf("Digits      : %d\n", count_digits(str));
    printf("Sentences   : %d\n", count_sentences(str));
    printf("Spaces      : %d\n", count_spaces(str));

    if (frequent != '\0') {
        printf("Most Frequent Character: %c\n", frequent);
    } else {
        printf("Most Frequent Character: None\n");
    }

    printf("=========================\n");
}
