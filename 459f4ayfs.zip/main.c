
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define FILE_NAME "diary.txt"
#define TEMP_FILE "diary_temp.txt"

// Function to check whether an entry exists for a date
int entry_exists(const char *date) {
    FILE *fp;
    char line[100];
    char marker[100];

    fp = fopen(FILE_NAME, "r");

    if (fp == NULL)
        return 0;

    snprintf(marker, sizeof(marker), "---DATE:%s---", date);

    while (fgets(line, sizeof(line), fp) != NULL) {
        line[strcspn(line, "\r\n")] = '\0';

        if (strcmp(line, marker) == 0) {
            fclose(fp);
            return 1;
        }
    }

    fclose(fp);
    return 0;
}

// Task 1: Write a new diary entry
void write_entry(char *date, char *text) {
    FILE *fp;

    if (entry_exists(date)) {
        printf("\nAn entry for %s already exists!\n", date);
        printf("Delete the old entry before writing a new one.\n");
        return;
    }

    fp = fopen(FILE_NAME, "a");

    if (fp == NULL) {
        printf("Error: Unable to open diary file.\n");
        return;
    }

    fprintf(fp, "---DATE:%s---\n", date);
    fprintf(fp, "%s", text);
    fprintf(fp, "---END---\n");

    fclose(fp);

    printf("\nDiary entry saved successfully!\n");
}

// Task 1: Read an entry by date
void read_entry(char *date) {
    FILE *fp;
    char line[500];
    char marker[100];
    int found = 0;
    int inside_entry = 0;

    fp = fopen(FILE_NAME, "r");

    if (fp == NULL) {
        printf("\nDiary file does not exist yet.\n");
        return;
    }

    snprintf(marker, sizeof(marker), "---DATE:%s---", date);

    while (fgets(line, sizeof(line), fp) != NULL) {
        line[strcspn(line, "\r\n")] = '\0';

        if (!inside_entry && strcmp(line, marker) == 0) {
            found = 1;
            inside_entry = 1;
            printf("\n===== Diary Entry: %s =====\n", date);
            continue;
        }

        if (inside_entry) {
            if (strcmp(line, "---END---") == 0)
                break;

            printf("%s\n", line);
        }
    }

    fclose(fp);

    if (!found)
        printf("\nNo entry found for %s.\n", date);

    if (found)
        printf("==============================\n");
}

// Task 2: List all diary entry dates
void list_entries() {
    FILE *fp;
    char line[100];
    char date[50];
    int count = 0;
    char *start;
    char *end;

    fp = fopen(FILE_NAME, "r");

    if (fp == NULL) {
        printf("\nNo diary entries available.\n");
        return;
    }

    printf("\n========== DIARY ENTRIES ==========\n");

    while (fgets(line, sizeof(line), fp) != NULL) {
        start = strstr(line, "---DATE:");

        if (start != NULL) {
            start += 8;
            end = strstr(start, "---");

            if (end != NULL) {
                size_t len = (size_t)(end - start);

                if (len < sizeof(date)) {
                    strncpy(date, start, len);
                    date[len] = '\0';

                    printf("%d. %s\n", ++count, date);
                }
            }
        }
    }

    if (count == 0)
        printf("No entries found.\n");

    printf("===================================\n");

    fclose(fp);
}

// Task 2: Delete an entry using a temporary file
void delete_entry(char *date) {
    FILE *fp, *temp;
    char line[500];
    char marker[100];
    int found = 0;
    int skip_entry = 0;
    int error = 0;

    fp = fopen(FILE_NAME, "r");

    if (fp == NULL) {
        printf("\nDiary file does not exist.\n");
        return;
    }

    temp = fopen(TEMP_FILE, "w");

    if (temp == NULL) {
        printf("\nError: Cannot create temporary file.\n");
        fclose(fp);
        return;
    }

    snprintf(marker, sizeof(marker), "---DATE:%s---", date);

    while (fgets(line, sizeof(line), fp) != NULL) {
        char check_line[500];

        strcpy(check_line, line);
        check_line[strcspn(check_line, "\r\n")] = '\0';

        if (!skip_entry && strcmp(check_line, marker) == 0) {
            found = 1;
            skip_entry = 1;
            continue;
        }

        if (skip_entry) {
            if (strcmp(check_line, "---END---") == 0) {
                skip_entry = 0;
            }
            continue;
        }

        if (fputs(line, temp) == EOF) {
            error = 1;
            break;
        }
    }

    if (ferror(fp) || fclose(fp) != 0)
        error = 1;

    if (fclose(temp) != 0)
        error = 1;

    if (error) {
        printf("\nError while processing diary file. Original file was not replaced.\n");
        remove(TEMP_FILE);
        return;
    }

    if (!found) {
        printf("\nNo entry found for %s.\n", date);
        remove(TEMP_FILE);
        return;
    }

    // Replace original file with temporary file
    if (remove(FILE_NAME) != 0) {
        printf("\nError: Could not remove original diary file.\n");
        remove(TEMP_FILE);
        return;
    }

    if (rename(TEMP_FILE, FILE_NAME) != 0) {
        printf("\nError: Could not rename temporary file.\n");
        printf("The remaining entries are in diary_temp.txt.\n");
        return;
    }

    printf("\nEntry for %s deleted successfully!\n", date);
}

// Task 3: Main menu
int main() {
    int choice;
    char date[50];
    char text[5000];
    char line[500];

    while (1) {
        printf("\n========== MY DIARY ==========\n");
        printf("1. Write Today's Entry\n");
        printf("2. Read an Entry\n");
        printf("3. List All Entries\n");
        printf("4. Delete an Entry\n");
        printf("5. Exit\n");
        printf("==============================\n");

        printf("Enter your choice: ");

        if (scanf("%d", &choice) != 1) {
            printf("Invalid input. Please enter a number.\n");

            int ch;
            while ((ch = getchar()) != '\n' && ch != EOF);
            continue;
        }

        // Clear input buffer
        int ch;
        while ((ch = getchar()) != '\n' && ch != EOF);

        switch (choice) {

            case 1:
                printf("\nEnter date (DD-MM-YYYY): ");
                if (fgets(date, sizeof(date), stdin) == NULL)
                    break;

                date[strcspn(date, "\r\n")] = '\0';

                if (strlen(date) == 0) {
                    printf("Date cannot be empty.\n");
                    break;
                }

                if (entry_exists(date)) {
                    printf("\nAn entry for %s already exists.\n", date);
                    printf("Delete the old entry before writing a new one.\n");
                    break;
                }

                printf("\nWrite your diary entry.\n");
                printf("Enter '.' on a separate line to finish:\n\n");

                text[0] = '\0';

                while (fgets(line, sizeof(line), stdin) != NULL) {
                    if (strcmp(line, ".\n") == 0 ||
                        strcmp(line, ".\r\n") == 0 ||
                        strcmp(line, ".") == 0) {
                        break;
                    }

                    if (strlen(text) + strlen(line) < sizeof(text) - 1) {
                        strcat(text, line);
                    } else {
                        printf("Entry is full. Saving collected text.\n");
                        break;
                    }
                }

                write_entry(date, text);
                break;

            case 2:
                printf("\nEnter date to read (DD-MM-YYYY): ");
                if (fgets(date, sizeof(date), stdin) == NULL)
                    break;

                date[strcspn(date, "\r\n")] = '\0';
                read_entry(date);
                break;

            case 3:
                list_entries();
                break;

            case 4:
                printf("\nEnter date to delete (DD-MM-YYYY): ");
                if (fgets(date, sizeof(date), stdin) == NULL)
                    break;

                date[strcspn(date, "\r\n")] = '\0';
                delete_entry(date);
                break;

            case 5:
                printf("\nThank you for using Personal Diary!\n");
                return 0;

            default:
                printf("\nInvalid choice! Please try again.\n");
        }
    }

    return 0;
}
