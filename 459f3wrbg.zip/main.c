
#include <stdio.h>
#include <stdlib.h>

typedef struct {
    char name[50];
    float price;
    int quantity;
} Item;

// Function declarations
void add_item(Item **list, int *count, int *capacity);
void display_list(Item *list, int count);
void remove_item(Item *list, int *count, int index);
float compute_total(Item *list, int count);
void clear_list(Item **list, int *count, int *capacity);

int main() {

    int count = 0;
    int capacity = 2;
    int choice, index;

    float session_total = 0;

    // Initial dynamic memory allocation
    Item *list = malloc(capacity * sizeof(Item));

    if (list == NULL) {
        printf("Memory allocation failed!\n");
        return 1;
    }

    do {
        printf("\n===== SHOPPING LIST =====\n");
        printf("1. Add Item\n");
        printf("2. View List\n");
        printf("3. Remove Item\n");
        printf("4. Clear List\n");
        printf("5. Exit\n");
        printf("=========================\n");

        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {

            // TASK 1: Add Item
            case 1:
                add_item(&list, &count, &capacity);

                printf("\nCurrent Count    : %d\n", count);
                printf("Current Capacity : %d\n", capacity);
                break;

            // TASK 2: Display List
            case 2:
                display_list(list, count);
                break;

            // Remove Item
            case 3:

                if (count == 0) {
                    printf("Shopping list is empty!\n");
                    break;
                }

                display_list(list, count);

                printf("\nEnter item number to remove: ");
                scanf("%d", &index);

                if (index < 1 || index > count) {
                    printf("Invalid item number!\n");
                }
                else {
                    remove_item(list, &count, index - 1);
                    printf("Item removed successfully!\n");
                }

                break;

            // TASK 3: Clear List
            case 4:
                clear_list(&list, &count, &capacity);
                printf("Shopping list cleared successfully!\n");
                break;

            // Exit
            case 5:
                session_total = compute_total(list, count);

                printf("\n===== SESSION SUMMARY =====\n");
                printf("Final Shopping Total: Rs. %.2f\n",
                       session_total);

                printf("Thank you for shopping!\n");

                free(list);
                list = NULL;
                break;

            default:
                printf("Invalid choice! Try again.\n");
        }

    } while (choice != 5);

    return 0;
}

// Add item using malloc and realloc
void add_item(Item **list, int *count, int *capacity) {

    // Increase capacity when full
    if (*count == *capacity) {

        int new_capacity = (*capacity) * 2;

        Item *temp = realloc(*list,
                             new_capacity * sizeof(Item));

        if (temp == NULL) {
            printf("Memory reallocation failed!\n");
            return;
        }

        *list = temp;
        *capacity = new_capacity;

        printf("\nMemory expanded successfully!\n");
    }

    printf("\nEnter item name: ");
    scanf(" %49[^\n]", (*list)[*count].name);

    printf("Enter item price: Rs. ");
    scanf("%f", &(*list)[*count].price);

    printf("Enter quantity: ");
    scanf("%d", &(*list)[*count].quantity);

    if ((*list)[*count].price < 0 ||
        (*list)[*count].quantity <= 0) {

        printf("Invalid price or quantity! Item not added.\n");
        return;
    }

    (*count)++;

    printf("\nItem added successfully!\n");
}

// Calculate total amount
float compute_total(Item *list, int count) {

    float total = 0;

    for (int i = 0; i < count; i++) {
        total += list[i].price * list[i].quantity;
    }

    return total;
}

// Display shopping list
void display_list(Item *list, int count) {

    if (count == 0) {
        printf("\nShopping list is empty!\n");
        return;
    }

    printf("\n========== SHOPPING LIST ==========\n");

    printf("%-5s %-20s %-6s %-10s %-10s\n",
           "No.", "Item", "Qty", "Price", "Total");

    printf("-----------------------------------------------\n");

    for (int i = 0; i < count; i++) {

        float line_total = list[i].price *
                           list[i].quantity;

        printf("%-5d %-20s %-6d Rs.%-7.2f Rs.%.2f\n",
               i + 1,
               list[i].name,
               list[i].quantity,
               list[i].price,
               line_total);
    }

    printf("-----------------------------------------------\n");

    printf("Grand Total: Rs. %.2f\n",
           compute_total(list, count));

    printf("===============================================\n");
}

// Remove item by shifting elements
void remove_item(Item *list, int *count, int index) {

    for (int i = index; i < *count - 1; i++) {
        list[i] = list[i + 1];
    }

    (*count)--;
}

// Clear list and allocate fresh memory
void clear_list(Item **list, int *count, int *capacity) {

    free(*list);
    *list = NULL;

    *capacity = 2;
    *count = 0;

    *list = malloc(*capacity * sizeof(Item));

    if (*list == NULL) {
        *capacity = 0;
        printf("Memory allocation failed!\n");
    }
}
