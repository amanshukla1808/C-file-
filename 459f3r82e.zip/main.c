
#include <stdio.h>

// TASK 1: Conversion Function Declarations
void celsius_to_fahrenheit(float *temp);
void celsius_to_kelvin(float *temp);
void fahrenheit_to_celsius(float *temp);
void kelvin_to_celsius(float *temp);

// TASK 2: Function Pointer
void convert_array(float arr[], int n,
                   void (*convert_fn)(float *));

// TASK 3: Analysis Functions
void find_hottest(float arr[], char cities[][30], int n,
                  float **max_temp, char **max_city);

void find_coldest(float arr[], char cities[][30], int n,
                  float **min_temp, char **min_city);

float average_temp(float arr[], int n);

int main() {

    // TASK 1: Test Conversion Functions
    float temp = 100.0;

    printf("===== TEMPERATURE CONVERSION =====\n");

    printf("Original Celsius: %.2f\n", temp);

    celsius_to_fahrenheit(&temp);

    printf("After Fahrenheit Conversion: %.2f F\n", temp);

    // Test all four conversions
    float c = 0.0;
    celsius_to_fahrenheit(&c);
    printf("\n0 Celsius = %.2f Fahrenheit\n", c);

    c = 0.0;
    celsius_to_kelvin(&c);
    printf("0 Celsius = %.2f Kelvin\n", c);

    float f = 212.0;
    fahrenheit_to_celsius(&f);
    printf("212 Fahrenheit = %.2f Celsius\n", f);

    float k = 373.15;
    kelvin_to_celsius(&k);
    printf("373.15 Kelvin = %.2f Celsius\n", k);

    // TASK 2: City Temperature Array
    char cities[8][30] = {
        "Delhi", "Mumbai", "Chennai", "Kolkata",
        "Bengaluru", "Hyderabad", "Jaipur", "Pune"
    };

    float temps[8] = {
        42.1, 36.5, 38.8, 34.2,
        28.9, 40.3, 45.6, 33.1
    };

    char unit;

    printf("\n===== CITY TEMPERATURE CONVERTER =====\n");

    printf("Choose conversion unit:\n");
    printf("F - Fahrenheit\n");
    printf("K - Kelvin\n");
    printf("Enter your choice: ");
    scanf(" %c", &unit);

    if (unit == 'F' || unit == 'f') {

        convert_array(temps, 8, celsius_to_fahrenheit);
        printf("\nCity Temperature (Fahrenheit)\n");

    }
    else if (unit == 'K' || unit == 'k') {

        convert_array(temps, 8, celsius_to_kelvin);
        printf("\nCity Temperature (Kelvin)\n");

    }
    else {

        printf("Invalid unit selected!\n");
        return 0;
    }

    printf("--------------------------------\n");
    printf("%-15s %s\n", "City", "Temperature");
    printf("--------------------------------\n");

    for (int i = 0; i < 8; i++) {
        printf("%-15s %.2f\n", cities[i], temps[i]);
    }

    // TASK 3: Hottest and Coldest City
    // Use original Celsius data for analysis
    float original_temps[8] = {
        42.1, 36.5, 38.8, 34.2,
        28.9, 40.3, 45.6, 33.1
    };

    float *max_temp;
    float *min_temp;

    char *max_city;
    char *min_city;

    find_hottest(original_temps, cities, 8,
                 &max_temp, &max_city);

    find_coldest(original_temps, cities, 8,
                 &min_temp, &min_city);

    float avg = average_temp(original_temps, 8);

    printf("\n===== TEMPERATURE ANALYSIS =====\n");

    printf("Hottest City : %s (%.2f C)\n",
           max_city, *max_temp);

    printf("Coldest City : %s (%.2f C)\n",
           min_city, *min_temp);

    printf("Average Temp : %.2f C\n", avg);

    printf("================================\n");

    return 0;
}

// Celsius to Fahrenheit
void celsius_to_fahrenheit(float *temp) {
    *temp = (*temp * 9.0 / 5.0) + 32;
}

// Celsius to Kelvin
void celsius_to_kelvin(float *temp) {
    *temp = *temp + 273.15;
}

// Fahrenheit to Celsius
void fahrenheit_to_celsius(float *temp) {
    *temp = (*temp - 32) * 5.0 / 9.0;
}

// Kelvin to Celsius
void kelvin_to_celsius(float *temp) {
    *temp = *temp - 273.15;
}

// Apply conversion using function pointer
void convert_array(float arr[], int n,
                   void (*convert_fn)(float *)) {

    for (int i = 0; i < n; i++) {
        convert_fn(&arr[i]);
    }
}

// Find hottest city using pointer-to-pointer
void find_hottest(float arr[], char cities[][30], int n,
                  float **max_temp, char **max_city) {

    int max_index = 0;

    for (int i = 1; i < n; i++) {

        if (arr[i] > arr[max_index]) {
            max_index = i;
        }
    }

    *max_temp = &arr[max_index];
    *max_city = cities[max_index];
}

// Find coldest city using pointer-to-pointer
void find_coldest(float arr[], char cities[][30], int n,
                  float **min_temp, char **min_city) {

    int min_index = 0;

    for (int i = 1; i < n; i++) {

        if (arr[i] < arr[min_index]) {
            min_index = i;
        }
    }

    *min_temp = &arr[min_index];
    *min_city = cities[min_index];
}

// Calculate average using pointer arithmetic
float average_temp(float arr[], int n) {

    float sum = 0;

    for (int i = 0; i < n; i++) {
        sum += *(arr + i);
    }

    return sum / n;
}
