
#include <stdio.h>

// Function declarations
float total_rainfall(float arr[], int n);
float average_rainfall(float arr[], int n);
int wettest_day(float arr[], int n);
int driest_day(float arr[], int n);
int count_above_threshold(float arr[], int n, float threshold);

void enter_rainfall(float arr[], int n);
void display_rainfall(float arr[], int n);
void display_summary(float arr[], int n);

int main() {

    float rainfall1[31], rainfall2[31];
    int days1, days2;
    char choice;

    // TASK 1: First Month Data
    printf("===== RAINFALL ANALYSIS SYSTEM =====\n");

    printf("\nEnter number of days for Month 1 (1-31): ");
    scanf("%d", &days1);

    if (days1 < 1 || days1 > 31) {
        printf("Invalid number of days!\n");
        return 0;
    }

    enter_rainfall(rainfall1, days1);

    printf("\n===== MONTH 1 RAINFALL DATA =====\n");
    display_rainfall(rainfall1, days1);

    // TASK 2: Statistical Summary
    printf("\n===== MONTH 1 SUMMARY =====\n");
    display_summary(rainfall1, days1);

    // TASK 3: Monthly Comparison
    printf("\nDo you want to enter data for second month? (y/n): ");
    scanf(" %c", &choice);

    if (choice == 'y' || choice == 'Y') {

        printf("\nEnter number of days for Month 2 (1-31): ");
        scanf("%d", &days2);

        if (days2 < 1 || days2 > 31) {
            printf("Invalid number of days!\n");
            return 0;
        }

        enter_rainfall(rainfall2, days2);

        printf("\n===== MONTH 2 RAINFALL DATA =====\n");
        display_rainfall(rainfall2, days2);

        printf("\n===== MONTH 2 SUMMARY =====\n");
        display_summary(rainfall2, days2);

        // Compare months
        float total1 = total_rainfall(rainfall1, days1);
        float total2 = total_rainfall(rainfall2, days2);

        float avg1 = average_rainfall(rainfall1, days1);
        float avg2 = average_rainfall(rainfall2, days2);

        int wet1 = count_above_threshold(rainfall1, days1, 25);
        int wet2 = count_above_threshold(rainfall2, days2, 25);

        printf("\n===== MONTHLY COMPARISON =====\n");

        printf("\n                    Month 1       Month 2\n");
        printf("------------------------------------------\n");

        printf("Total Rainfall      %.2f mm      %.2f mm\n",
               total1, total2);

        printf("Average Rainfall    %.2f mm      %.2f mm\n",
               avg1, avg2);

        printf("Days Above 25mm     %d             %d\n",
               wet1, wet2);

        printf("------------------------------------------\n");

        if (total1 > total2) {
            printf("Month 1 had higher total rainfall.\n");
        }
        else if (total2 > total1) {
            printf("Month 2 had higher total rainfall.\n");
        }
        else {
            printf("Both months had equal rainfall.\n");
        }

        if (wet1 > wet2) {
            printf("Month 1 had more days above 25mm.\n");
        }
        else if (wet2 > wet1) {
            printf("Month 2 had more days above 25mm.\n");
        }
        else {
            printf("Both months had equal days above 25mm.\n");
        }

        printf("Difference in average rainfall: %.2f mm\n",
               (avg1 > avg2) ? avg1 - avg2 : avg2 - avg1);
    }

    printf("\nThank you for using Rainfall Analysis System!\n");

    return 0;
}

// Function to enter rainfall data
void enter_rainfall(float arr[], int n) {

    for (int i = 0; i < n; i++) {

        do {
            printf("Enter rainfall for Day %d (mm): ", i + 1);
            scanf("%f", &arr[i]);

            if (arr[i] < 0) {
                printf("Invalid! Rainfall cannot be negative.\n");
            }

        } while (arr[i] < 0);
    }
}

// Function to display rainfall data
void display_rainfall(float arr[], int n) {

    printf("\nDay\tRainfall (mm)\n");
    printf("-------------------------\n");

    for (int i = 0; i < n; i++) {
        printf("%d\t%.2f\n", i + 1, arr[i]);
    }
}

// Calculate total rainfall
float total_rainfall(float arr[], int n) {

    float sum = 0;

    for (int i = 0; i < n; i++) {
        sum += arr[i];
    }

    return sum;
}

// Calculate average rainfall
float average_rainfall(float arr[], int n) {

    return total_rainfall(arr, n) / n;
}

// Find wettest day
int wettest_day(float arr[], int n) {

    int max = 0;

    for (int i = 1; i < n; i++) {
        if (arr[i] > arr[max]) {
            max = i;
        }
    }

    return max;
}

// Find driest day
int driest_day(float arr[], int n) {

    int min = 0;

    for (int i = 1; i < n; i++) {
        if (arr[i] < arr[min]) {
            min = i;
        }
    }

    return min;
}

// Count days above threshold
int count_above_threshold(float arr[], int n, float threshold) {

    int count = 0;

    for (int i = 0; i < n; i++) {
        if (arr[i] > threshold) {
            count++;
        }
    }

    return count;
}

// Display statistical summary
void display_summary(float arr[], int n) {

    float total = total_rainfall(arr, n);
    float average = average_rainfall(arr, n);

    int wettest = wettest_day(arr, n);
    int driest = driest_day(arr, n);

    int above25 = count_above_threshold(arr, n, 25);

    printf("Total Rainfall    : %.2f mm\n", total);
    printf("Average per Day   : %.2f mm\n", average);

    printf("Wettest Day       : Day %d (%.2f mm)\n",
           wettest + 1, arr[wettest]);

    printf("Driest Day        : Day %d (%.2f mm)\n",
           driest + 1, arr[driest]);

    printf("Days above 25mm   : %d\n", above25);

    printf("============================\n");
}
