
#include <stdio.h>
#include <string.h>
#include <ctype.h>

typedef struct {
    char name[50];
    char role[20];
    int matches;
    int runs_scored;
    int wickets_taken;
    float batting_avg;
    float bowling_avg;
    int runs_conceded;
} Player;

// Convert a string to lowercase for case-insensitive comparison
void to_lowercase(char str[]) {
    int i;
    for (i = 0; str[i] != '\0'; i++) {
        str[i] = (char)tolower((unsigned char)str[i]);
    }
}

// Task 1: Enter player details
void enter_player(Player *p) {
    printf("\nEnter player name: ");
    scanf(" %49[^\n]", p->name);

    printf("Enter role (Batsman/Bowler/All-Rounder/Wicket-Keeper): ");
    scanf(" %19[^\n]", p->role);

    printf("Enter matches played: ");
    scanf("%d", &p->matches);

    printf("Enter runs scored: ");
    scanf("%d", &p->runs_scored);

    printf("Enter wickets taken: ");
    scanf("%d", &p->wickets_taken);

    printf("Enter runs conceded: ");
    scanf("%d", &p->runs_conceded);

    if (p->matches > 0)
        p->batting_avg = (float)p->runs_scored / p->matches;
    else
        p->batting_avg = 0.0;

    if (p->wickets_taken > 0)
        p->bowling_avg = (float)p->runs_conceded / p->wickets_taken;
    else
        p->bowling_avg = 0.0;
}

// Task 2: Display one player
void display_player(const Player *p) {
    printf("\nName          : %s", p->name);
    printf("\nRole          : %s", p->role);
    printf("\nMatches       : %d", p->matches);
    printf("\nRuns Scored   : %d", p->runs_scored);
    printf("\nWickets Taken : %d", p->wickets_taken);
    printf("\nBatting Avg   : %.2f", p->batting_avg);
    printf("\nBowling Avg   : %.2f\n", p->bowling_avg);
}

// Display complete team sheet
void display_team_sheet(Player squad[], int n) {
    int i;

    printf("\n===================== TEAM SHEET =====================\n");
    printf("%-4s %-22s %-17s %-10s %-8s\n",
           "No.", "Name", "Role", "Bat Avg", "Wickets");
    printf("------------------------------------------------------\n");

    for (i = 0; i < n; i++) {
        printf("%-4d %-22s %-17s %-10.2f %-8d\n",
               i + 1,
               squad[i].name,
               squad[i].role,
               squad[i].batting_avg,
               squad[i].wickets_taken);
    }

    printf("======================================================\n");
}

// Display players according to role
void display_by_role(Player squad[], int n, char *role) {
    int i, found = 0;
    char input_role[20];
    char stored_role[20];

    strcpy(input_role, role);
    to_lowercase(input_role);

    printf("\nPlayers with role: %s\n", role);
    printf("----------------------------------------\n");

    for (i = 0; i < n; i++) {
        strcpy(stored_role, squad[i].role);
        to_lowercase(stored_role);

        if (strcmp(input_role, stored_role) == 0) {
            display_player(&squad[i]);
            found = 1;
        }
    }

    if (!found)
        printf("No players found with this role.\n");
}

// Task 3: Find best batsman
Player *best_batsman(Player squad[], int n) {
    int i;
    Player *best = NULL;

    for (i = 0; i < n; i++) {
        if (best == NULL ||
            squad[i].batting_avg > best->batting_avg) {
            best = &squad[i];
        }
    }

    return best;
}

// Find best bowler based on wickets
Player *best_bowler(Player squad[], int n) {
    int i;
    Player *best = NULL;

    for (i = 0; i < n; i++) {
        if (squad[i].wickets_taken > 0 &&
            (best == NULL ||
             squad[i].wickets_taken > best->wickets_taken)) {
            best = &squad[i];
        }
    }

    return best;
}

// Calculate team batting average
float team_batting_average(Player squad[], int n) {
    int i;
    float sum = 0.0;

    if (n <= 0)
        return 0.0;

    for (i = 0; i < n; i++) {
        sum += squad[i].batting_avg;
    }

    return sum / n;
}

// Calculate total wickets
int total_wickets(Player squad[], int n) {
    int i, total = 0;

    for (i = 0; i < n; i++) {
        total += squad[i].wickets_taken;
    }

    return total;
}

// Display team summary
void display_team_summary(Player squad[], int n) {
    Player *batsman = best_batsman(squad, n);
    Player *bowler = best_bowler(squad, n);

    printf("\n============= TEAM SUMMARY =============\n");

    if (batsman != NULL)
        printf("Best Batsman : %s (Avg %.2f)\n",
               batsman->name, batsman->batting_avg);
    else
        printf("Best Batsman : Not available\n");

    if (bowler != NULL)
        printf("Best Bowler  : %s (%d wickets)\n",
               bowler->name, bowler->wickets_taken);
    else
        printf("Best Bowler  : No player has taken wickets\n");

    printf("Team Bat Avg : %.2f\n",
           team_batting_average(squad, n));

    printf("Total Wickets: %d\n",
           total_wickets(squad, n));

    printf("========================================\n");
}

// Main function
int main() {
    Player squad[11];
    int i;
    char role[20];

    printf("====================================\n");
    printf("       IPL CRICKET TEAM MANAGER\n");
    printf("====================================\n");

    // Task 1: Enter 11 players
    printf("\nEnter details of 11 players:\n");

    for (i = 0; i < 11; i++) {
        printf("\n========== PLAYER %d ==========\n", i + 1);
        enter_player(&squad[i]);
    }

    // Task 2: Display team sheet
    display_team_sheet(squad, 11);

    // Display individual player
    printf("\n========== PLAYER DETAILS ==========\n");
    display_player(&squad[0]);

    // Search players by role
    printf("\nEnter role to search (e.g. Batsman): ");
    scanf(" %19[^\n]", role);

    display_by_role(squad, 11, role);

    // Task 3: Display team statistics
    display_team_summary(squad, 11);

    return 0;
}
