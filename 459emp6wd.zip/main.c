
#include <stdio.h>

int main() {
    double num1, num2, result;
    char op, again;

    do {
        // Input
        printf("\n===== C CALCULATOR =====\n");

        printf("Enter first number  : ");
        scanf("%lf", &num1);

        printf("Enter operator (+, -, *, /, %%, ^): ");
        scanf(" %c", &op);

        printf("Enter second number : ");
        scanf("%lf", &num2);

        // Operations
        switch (op) {

            case '+':
                result = num1 + num2;
                printf("Result: %.2lf + %.2lf = %.2lf\n",
                       num1, num2, result);
                break;

            case '-':
                result = num1 - num2;
                printf("Result: %.2lf - %.2lf = %.2lf\n",
                       num1, num2, result);
                break;

            case '*':
                result = num1 * num2;
                printf("Result: %.2lf * %.2lf = %.2lf\n",
                       num1, num2, result);
                break;

            case '/':
                if (num2 == 0) {
                    printf("Error! Division by zero is not allowed.\n");
                } else {
                    result = num1 / num2;
                    printf("Result: %.2lf / %.2lf = %.2lf\n",
                           num1, num2, result);
                }
                break;

            case '%':
                if (num1 != (int)num1 || num2 != (int)num2) {
                    printf("Error! Modulus works only with integers.\n");
                }
                else if (num2 == 0) {
                    printf("Error! Modulus by zero is not allowed.\n");
                }
                else {
                    result = (int)num1 % (int)num2;
                    printf("Result: %d %% %d = %.0lf\n",
                           (int)num1, (int)num2, result);
                }
                break;

            case '^':
                result = 1;

                if (num2 >= 0) {
                    for (int i = 0; i < (int)num2; i++) {
                        result = result * num1;
                    }
                }
                else {
                    if (num1 == 0) {
                        printf("Error! Zero cannot have a negative exponent.\n");
                        break;
                    }

                    for (int i = 0; i > (int)num2; i--) {
                        result = result * num1;
                    }

                    result = 1 / result;
                }

                printf("Result: %.2lf ^ %.2lf = %.2lf\n",
                       num1, num2, result);
                break;

            default:
                printf("Error! Invalid operator.\n");
        }

        // Ask to calculate again
        while (1) {
            printf("\nCalculate again? (y/n): ");
            scanf(" %c", &again);

            if (again == 'y' || again == 'Y' ||
                again == 'n' || again == 'N') {
                break;
            }

            printf("Invalid input! Enter y or n.\n");
        }

    } while (again == 'y' || again == 'Y');

    printf("\nThank you for using the calculator!\n");

    return 0;
}
