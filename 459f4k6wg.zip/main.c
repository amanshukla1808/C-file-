
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define MAX_STUDENTS 100
#define MAX_SUBJECTS 6
#define MAX_NAME 50

#define FILE_NAME "results.dat"

typedef struct {
    int roll_number;
    char name[MAX_NAME];
    int marks[MAX_SUBJECTS];
    int num_subjects;
    float average;
    char grade;
    int passed;
} Student;

// Function declarations
void compute_result(Student *s);
void display_student(const Student *s);
void add_student(Student *arr, int *count);
void display_all(Student *arr, int n);
Student *search_by_roll(Student *arr, int n, int roll);
void sort_by_average(Student *arr, int n);
void display_rank_list(Student *arr, int n);
Student *topper(Student *arr, int n);
void compute_stats(Student *arr, int n);
void display_failures(Student *arr, int n);
void save_to_file(Student *arr, int n, const char *filename);
void load_from_file(Student *arr, int *n, const char *filename);

// Input functions
int read_integer(const char *message) {
    char input[100];
    char extra;
    int value;

    while (1) {
        printf("%s", message);

        if (fgets(input, sizeof(input), stdin) == NULL)
            exit(1);

        if (sscanf(input, " %d %c", &value, &extra) == 1)
            return value;

        printf("Invalid input! Enter an integer.\n");
    }
}

void read_name(char name[], int size) {
    while (1) {
        printf("Enter student name: ");

        if (fgets(name, size, stdin) == NULL)
            exit(1);

        name[strcspn(name, "\n")] = '\0';

        // Handle an overlong input line
        if (strchr(name, '\0') == name + size - 1 &&
            name[size - 2] != '\n') {
            int ch;
            while ((ch = getchar()) != '\n' && ch != EOF);
            printf("Name is too long. Try again.\n");
            continue;
        }

        if (strlen(name) == 0) {
            printf("Name cannot be empty!\n");
            continue;
        }

        return;
    }
}

// Stage 1: Compute total, average, grade and result
void compute_result(Student *s) {
    int i;
    int total = 0;
    s->passed = 1;

    for (i = 0; i < s->num_subjects; i++) {
        total += s->marks[i];

        if (s->marks[i] < 35)
            s->passed = 0;
    }

    if (s->num_subjects > 0)
        s->average = (float)total / s->num_subjects;
    else
        s->average = 0.0;

    if (s->average >= 90)
        s->grade = 'A';
    else if (s->average >= 75)
        s->grade = 'B';
    else if (s->average >= 60)
        s->grade = 'C';
    else if (s->average >= 50)
        s->grade = 'D';
    else
        s->grade = 'F';
}

// Display one student
void display_student(const Student *s) {
    int i;
    int total = 0;

    for (i = 0; i < s->num_subjects; i++)
        total += s->marks[i];

    printf("\n============================================\n");
    printf("                RESULT CARD\n");
    printf("============================================\n");

    printf("Roll No   : %d\n", s->roll_number);
    printf("Name      : %s\n", s->name);

    printf("--------------------------------------------\n");

    for (i = 0; i < s->num_subjects; i++)
        printf("Subject %-2d : %d\n", i + 1, s->marks[i]);

    printf("--------------------------------------------\n");
    printf("Total     : %d / %d\n",
           total, s->num_subjects * 100);
    printf("Average   : %.2f\n", s->average);
    printf("Grade     : %c\n", s->grade);
    printf("Result    : %s\n",
           s->passed ? "PASS" : "FAIL");

    printf("============================================\n");
}

// Stage 2: Add student
void add_student(Student *arr, int *count) {
    int i;
    Student s;

    if (*count >= MAX_STUDENTS) {
        printf("\nStudent limit reached!\n");
        return;
    }

    printf("\n========== ADD STUDENT ==========\n");

    while (1) {
        s.roll_number = read_integer("Enter roll number: ");

        if (s.roll_number <= 0) {
            printf("Roll number must be positive.\n");
            continue;
        }

        if (search_by_roll(arr, *count, s.roll_number) != NULL) {
            printf("This roll number already exists!\n");
            continue;
        }

        break;
    }

    read_name(s.name, MAX_NAME);

    while (1) {
        s.num_subjects = read_integer("Enter number of subjects (1-6): ");

        if (s.num_subjects >= 1 &&
            s.num_subjects <= MAX_SUBJECTS)
            break;

        printf("Enter between 1 and 6 subjects.\n");
    }

    for (i = 0; i < s.num_subjects; i++) {
        char message[80];

        while (1) {
            snprintf(message, sizeof(message),
                     "Enter marks for Subject %d (0-100): ", i + 1);

            s.marks[i] = read_integer(message);

            if (s.marks[i] >= 0 && s.marks[i] <= 100)
                break;

            printf("Marks must be between 0 and 100!\n");
        }
    }

    compute_result(&s);

    arr[*count] = s;
    (*count)++;

    printf("\nStudent added successfully!\n");
}

// Display all students
void display_all(Student *arr, int n) {
    int i;

    if (n == 0) {
        printf("\nNo student records available.\n");
        return;
    }

    for (i = 0; i < n; i++)
        display_student(&arr[i]);
}

// Search student by roll number
Student *search_by_roll(Student *arr, int n, int roll) {
    int i;

    for (i = 0; i < n; i++) {
        if (arr[i].roll_number == roll)
            return &arr[i];
    }

    return NULL;
}

// Stage 3: Bubble sort in descending average order
void sort_by_average(Student *arr, int n) {
    int i, j;
    Student temp;

    for (i = 0; i < n - 1; i++) {
        for (j = 0; j < n - i - 1; j++) {
            if (arr[j].average < arr[j + 1].average) {
                temp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = temp;
            }
        }
    }
}

// Display rank list
void display_rank_list(Student *arr, int n) {
    int i;

    if (n == 0) {
        printf("\nNo students available for ranking.\n");
        return;
    }

    sort_by_average(arr, n);

    printf("\n===================== RANK LIST =====================\n");
    printf("%-6s %-8s %-20s %-10s %-8s\n",
           "Rank", "Roll", "Name", "Average", "Grade");
    printf("-----------------------------------------------------\n");

    for (i = 0; i < n; i++) {
        printf("%-6d %-8d %-20s %-10.2f %-8c\n",
               i + 1,
               arr[i].roll_number,
               arr[i].name,
               arr[i].average,
               arr[i].grade);
    }

    printf("=====================================================\n");
}

// Find topper
Student *topper(Student *arr, int n) {
    int i;
    Student *best = NULL;

    for (i = 0; i < n; i++) {
        if (best == NULL || arr[i].average > best->average)
            best = &arr[i];
    }

    return best;
}

// Stage 4: Class statistics
void compute_stats(Student *arr, int n) {
    int i;
    int passed = 0, failed = 0;
    float total_average = 0.0;
    float highest, lowest;
    float pass_percentage;

    if (n == 0) {
        printf("\nNo records available for statistics.\n");
        return;
    }

    highest = lowest = arr[0].average;

    for (i = 0; i < n; i++) {
        total_average += arr[i].average;

        if (arr[i].passed)
            passed++;
        else
            failed++;

        if (arr[i].average > highest)
            highest = arr[i].average;

        if (arr[i].average < lowest)
            lowest = arr[i].average;
    }

    // Explicit float conversion avoids integer division
    pass_percentage = ((float)passed / n) * 100.0;

    printf("\n========== CLASS STATISTICS ==========\n");
    printf("Total Students   : %d\n", n);
    printf("Students Passed  : %d\n", passed);
    printf("Students Failed  : %d\n", failed);
    printf("Pass Percentage  : %.2f%%\n", pass_percentage);
    printf("Class Average    : %.2f\n", total_average / n);
    printf("Highest Average  : %.2f\n", highest);
    printf("Lowest Average   : %.2f\n", lowest);
    printf("======================================\n");
}

// Display students who failed
void display_failures(Student *arr, int n) {
    int i, j;
    int found = 0;

    printf("\n========== FAILURE REPORT ==========\n");

    for (i = 0; i < n; i++) {
        if (arr[i].passed == 0) {
            found = 1;

            printf("\nRoll Number: %d\n", arr[i].roll_number);
            printf("Name       : %s\n", arr[i].name);
            printf("Failed Subjects: ");

            for (j = 0; j < arr[i].num_subjects; j++) {
                if (arr[i].marks[j] < 35)
                    printf("Subject %d (%d marks)  ",
                           j + 1, arr[i].marks[j]);
            }

            printf("\n");
        }
    }

    if (!found)
        printf("No failed students!\n");

    printf("====================================\n");
}

// Find and display topper
void display_topper(Student *arr, int n) {
    Student *best = topper(arr, n);

    if (best == NULL) {
        printf("\nNo student records available.\n");
        return;
    }

    printf("\n========== CLASS TOPPER ==========\n");
    printf("Name    : %s\n", best->name);
    printf("Roll No : %d\n", best->roll_number);
    printf("Average : %.2f\n", best->average);
    printf("Grade   : %c\n", best->grade);
    printf("==================================\n");
}

// Stage 5: Save records in binary file
void save_to_file(Student *arr, int n, const char *filename) {
    FILE *fp = fopen(filename, "wb");

    if (fp == NULL) {
        printf("\nError opening file for saving!\n");
        return;
    }

    // Save record count first
    if (fwrite(&n, sizeof(int), 1, fp) != 1 ||
        (n > 0 && fwrite(arr, sizeof(Student), n, fp) != (size_t)n)) {
        printf("\nError writing records to file!\n");
        fclose(fp);
        return;
    }

    if (fclose(fp) != 0) {
        printf("\nError closing result file!\n");
        return;
    }

    printf("\nRecords saved successfully!\n");
}

// Load records from binary file
void load_from_file(Student *arr, int *n, const char *filename) {
    FILE *fp = fopen(filename, "rb");
    int saved_count;

    *n = 0;

    if (fp == NULL) {
        printf("\nNo previous result file found. Starting fresh.\n");
        return;
    }

    if (fread(&saved_count, sizeof(int), 1, fp) != 1 ||
        saved_count < 0 || saved_count > MAX_STUDENTS) {
        printf("\nInvalid or damaged result file. Starting fresh.\n");
        fclose(fp);
        return;
    }

    if (saved_count > 0 &&
        fread(arr, sizeof(Student), saved_count, fp) !=
        (size_t)saved_count) {
        printf("\nIncomplete or damaged result file. Starting fresh.\n");
        *n = 0;
        fclose(fp);
        return;
    }

    *n = saved_count;

    if (fclose(fp) != 0) {
        printf("\nWarning: Error closing result file.\n");
    }

    printf("\n%d student record(s) loaded successfully.\n", *n);
}

// Main function
int main() {
    Student *students;
    int count = 0;
    int choice;
    int roll;
    Student *found;

    // Stage 6: Dynamic memory allocation
    students = (Student *)malloc(MAX_STUDENTS * sizeof(Student));

    if (students == NULL) {
        printf("Memory allocation failed.\n");
        return 1;
    }

    // Load records when program starts
    load_from_file(students, &count, FILE_NAME);

    while (1) {
        printf("\n");
        printf("================================\n");
        printf("          RESULT PRO\n");
        printf("================================\n");
        printf("1. Add Student\n");
        printf("2. View All Students\n");
        printf("3. Search by Roll Number\n");
        printf("4. Rank List\n");
        printf("5. Class Statistics\n");
        printf("6. Failure Report\n");
        printf("7. View Class Topper\n");
        printf("8. Save Records\n");
        printf("9. Exit\n");
        printf("================================\n");

        choice = read_integer("Enter your choice: ");

        switch (choice) {

            case 1:
                add_student(students, &count);
                break;

            case 2:
                display_all(students, count);
                break;

            case 3:
                roll = read_integer("Enter roll number to search: ");

                found = search_by_roll(students, count, roll);

                if (found != NULL)
                    display_student(found);
                else
                    printf("\nStudent not found!\n");

                break;

            case 4:
                display_rank_list(students, count);
                break;

            case 5:
                compute_stats(students, count);
                break;

            case 6:
                display_failures(students, count);
                break;

            case 7:
                display_topper(students, count);
                break;

            case 8:
                save_to_file(students, count, FILE_NAME);
                break;

            case 9:
                save_to_file(students, count, FILE_NAME);

                free(students);
                students = NULL;

                printf("\nThank you for using ResultPro!\n");
                return 0;

            default:
                printf("\nInvalid choice! Please select 1-9.\n");
        }
    }
}
